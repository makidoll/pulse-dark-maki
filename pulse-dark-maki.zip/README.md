-   **Download latest version of theme**

    `deno run -A scripts/download-latest`

-   **Compile and zip**

    `deno run -A scripts/update-manifest.ts && scripts/make-zip.sh`
